<?php
	if(isset($_GET['id'])){
		echo "received";
	}
?>