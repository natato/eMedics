<?php
	session_start();
	unset($_SESSION['result1']);
	unset($_SESSION['result2']);
	unset($_SESSION['result3']);
	if(isset($_POST['con_search'])){
		require_once("Controller.php");
		$contr_obj=new Controller();
		$pat_id=$_POST['search_pat_id']; 
		$doc_id=$_POST['search_doc_id']; 
		$nurse_id=$_POST['search_nur_id']; 
		$nurse_id=$_POST['search_nur_id']; 
		$attended_date=$_POST['search_year']."-".$_POST['search_month']."-".$_POST['search_day'];
		$consultation=$contr_obj->getConsultation($pat_id, $attended_date);
		$patient=$contr_obj->getPatient($pat_id);
		$opd=$contr_obj->getOpd_Info($pat_id, $attended_date);
		if(empty($pat_id) or empty($attended_date)){
			$_SESSION['alert']="Patient ID and Date  must be included in the search parameters";
		}
		else if($consultation==false){
			$_SESSION['alert']="No results found for query";
		}
		else{
			$_SESSION['result1']=$consultation;
			$_SESSION['result2']=$opd;
			$_SESSION['result3']=$patient;
		}
	}
?>
<?php if(isset($_SESSION['username'])){?>
<html>
	<head> 
		<title>Consultation View</title> 
		<link rel="stylesheet" href="consultation_view.css" type="text/css"/>
		<script type="text/javascript" src="scripts.js"> </script>
	</head>
	<body>
		<div id="container">
		
			<div id="banner">
				<div class="logo">
					<i><h3>Medics Hospital Management System</h3></i>
				</div>
				<div class="menu">
					<div class="search">
						Patient ID:</br>
						<form action="patient_view.php" method="post">
							<input type="text" name="pat_ID"/> <input name="search" type="submit" value="Search"/>
						</form>
					</div>
					<a href="patient_view.php">Patients</a>
					<a href="consultation_view.php">Consultation</a>
					<a href="index.php">Logout</a>
				</div>
			</div>
			</br>
			<div id="newConsultation">
				<u style="color:gray">Consultation Search Results</u></br>
				<i style="color:lightblue">Identity & Dates:</i></br>
				<table width="390px">
					<tr><td>Doctor ID:<input type="text" value="<?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getDoctorID();} ?>"/></td> <td>Doctor Name:<input type="text" value="<?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getDoctorName();}?>"/></td></tr>
					<tr><td>Nurse ID:<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getNurseID(); }?>"/></td> <td>Nurse Name:<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getNurseName();}?>"/></td></tr>
					<tr><td> Patient ID:<input type="text" value="<?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getPatientID(); }?>"/></td><td>Patient Name:<input type="text" value="<?php if(isset($_SESSION['result3'])){echo $_SESSION['result3']->getName();}?>"/></td></tr>
					<tr><td>Date Scheduled:<input type="text" value="<?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getScheduledDate(); }?>"/></td> <td>Date Attended:<input type="text" value="<?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getAttendedDate();}?>"/></td></tr>
				</table>
				</br>
				<i style="color:lightblue">Consultation Details:</i>
				<table width="390px">
					<tr><td>Height:&nbsp;&nbsp;&nbsp;<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getHeight(); }?>"/></td> <td>Weight:<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getWeight();}?>"/></td></tr>
					<tr><td>Temperature:<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getTemperature(); }?>"/></td> <td>Blood Pressure:<input type="text" value="<?php if(isset($_SESSION['result2'])){echo $_SESSION['result2']->getBloodPressure();}?>"/></td></tr>
					<tr><td>Doctor's Remarks:<textarea><?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getRemarks(); }?></textarea></td> <td>Prescription:<textarea><?php if(isset($_SESSION['result1'])){echo $_SESSION['result1']->getPrescription();}?></textarea></td></tr>
				</table>
				<?php unset($_SESSION['result1']); unset($_SESSION['result2']);unset($_SESSION['result3']);?>
			</div>
			</div id="findConsultation">
				<u style="color:gray">Search Consultation Panel</u></br></br>
				<div class="params">
					<form action="consultation_search.php" method="post">
					<i class="searchParams">Seach Parameters:</i>
					<table>
						<tr>
							<td><input type="checkbox" id="checkbox1" onClick="show(1)" /><i class="searchParams">Patient ID:</i></td>
							<td><input type="text" id="search_pat_id" name="search_pat_id"   class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox2" onClick="show(2)"/><i class="searchParams">Doctor ID:</i></td>
							<td><input type="text" id="search_doc_id" name="search_doc_id" class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox3" onClick="show(3)"/><i class="searchParams">Nurse ID:</i></td>
							<td><input type="text" id="search_nur_id" name="search_nur_id" class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox4" onClick="show(4)"/><i class="searchParams">Date(dd-mm-yyy):</i></td>
							<td>
								<input type="text" id="search_day" name="search_day" class="hid_text"/>
								<input type="text" id="search_month" name="search_month" class="hid_text"/>
								<input type="text" id="search_year" name="search_year" class="hid_text"/>
							</td>
						</tr>
					</table>
					<input type="submit"  value="Search"/>
					</form>
				</div>
				<div id="results">
					<?php 
						if(isset($_SESSION['alert'])){
							echo "</br>"."<h5 style='color:orange'>".$_SESSION['alert']."</h5>";
						}
					?>
				</div>
			</div>
		</div>		
	</body>
</html>
<?php ;}?>