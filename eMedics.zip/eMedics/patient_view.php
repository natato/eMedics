<?php 
	session_start();
	$_SESSION['alert']="";
	function isEmpty($variable,$error_msg){
		if(empty($variable)){
			$_SESSION['alert']=$error_msg;
			return true;
		}
		return false;
	}
	function addPatient(){
		require_once("Controller.php");
		$contr_obj=new Controller();
		$pat_id=$_POST['pat_ID'];
		if(isEmpty($pat_id,"Patient ID field is empty")){
			return;
		}
		$pat_name=$_POST['pat_name'];
		if(isEmpty($pat_name,"Patient Name field is empty")){
			return;
		}
		$hometown=$_POST['hometown'];
		if(isEmpty($hometown,"Hometown field is empty")){
			return;
		}
		$residence=$_POST['residence'];
		if(isEmpty($residence,"Residence field is empty")){
			return;
		}
		$day=$_POST['day'];
		if(isEmpty($day,"The day field of Date of Birth is empty")){
			return;
		}
		$month=$_POST['month'];
		if(isEmpty($day,"The month field of Date of Birth is empty")){
			return;
		}
		$year=$_POST['year'];
		if(isEmpty($day,"The year field of Date of Birth is empty")){
			return;
		}
		$date_of_birth=$year."-".$month."-".$day;
		
		$parent_name=$_POST['parent_name'];
		if(isEmpty($parent_name,"Parent Name field is empty")){
			return;
		}
		$day2=$_POST['day2'];
		if(isEmpty($day,"The day field of Date Admitted is empty")){
			return;
		}
		$month2=$_POST['month2'];
		if(isEmpty($day,"The month field of Date Admitted is empty")){
			return;
		}
		$year2=$_POST['year2'];
		if(isEmpty($day,"The year field of Date Admitted is empty")){
			return;
		}
		$date_admitted=$year2."-".$month2."-".$day2;
		
		$illnes_description=$_POST['illness'];
		if(isEmpty($illnes_description,"Illness Description field is empty")){
			return;
		}
		 $result=$contr_obj->newPatient($pat_id,$pat_name,$hometown,$residence,$date_of_birth,$parent_name,$date_admitted,$illnes_description);
		if($result!=false){
			$_SESSION['alert']="New Patient Saved Successfully";
		}
	}
	if(isset($_POST['addPatient'])){
		addPatient();
	}
	else if(isset($_POST['search'])){
		require_once("Controller.php");
		$contr_obj=new Controller();
		$pat_id=$_POST['pat_ID'];
		$patient=$contr_obj->getPatient($pat_id);
		if($patient!=false){
			$_SESSION['searchResult']=$patient;
		}
	}
	else if(isset($_POST['edit'])){
		require_once("Controller.php");
		$contr_obj=new Controller();
		$id=$_POST['id'];
		echo $id;
		//if($contr_obj->editPatient($id)){
			//echo "success";
		//}
		
	}
	else if (isset($_POST['delete'])){
		require_once("Controller.php");
		$contr_obj=new Controller();
		$id=$_POST['id'];
		if($contr_obj->deletePatient($id)){
			echo "<script>alert('Patient deleted');</script>";
		}
			
			
	}
?>
<?php if(isset($_SESSION['username'])){?>
<html>
	<head> 
		<title>Patient View</title> 
		<link rel="stylesheet" href="patient_view.css" type="text/css"/>
		<script type="text/javascript" src="scripts.js"> </script>
	</head>
	<body>
		<div id="container">
			<div id="banner">
				<div class="logo">
					<i><h3>Medics Hospital Management System</h3></i>
				</div>
				<div class="menu">
					<div>
						Patient ID:</br>
						<form action="patient_view.php" method="post">
							<input type="text" name="pat_ID"/> <input name="search" type="submit" value="Search"/>
						</form>
					</div>
					<a href="patient_view.php">Patients</a>
					<a href="consultation_view.php">Consultation</a>
					<a href="index.php">Logout</a>
				</div>
			</div>
			</br>
			<div id="newPatient">
				<form action="patient_view.php" method="post">
				<u style="color:gray">New Patient Panel</u></br></br>
				Patient ID:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="pat_ID" class="big_input"/></br>
				Patient Name:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="pat_name" class="big_input"/></br>
				Hometown:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="hometown" class="big_input"/></br>
				Residence:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="residence" class="big_input"/></br>
				Date of Birth:(dd-mm-yyyy)</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="day" class="small_input"/>
				<input type="text" name="month" class="small_input"/>
				<input type="text" name="year" class="small_input"/>
				</br>
				Parent Name:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="parent_name" class="big_input"/></br>
				Date Admitted:(dd-mm-yyyy)</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="day2" class="small_input"/>
				<input type="text" name="month2" class="small_input"/>
				<input type="text" name="year2" class="small_input"/>
				</br>
				Illness Description:</br>
				&nbsp;&nbsp;&nbsp;&nbsp;<textarea  name="illness"> </textarea></br>
				</br>
				<input name="addPatient" type="submit" value="Save">&nbsp;&nbsp;<input type="reset"/>
				</form>
			</div>
			</div id="viewPatient">
				<u style="color:gray">View Patient Panel</u></br></br>
				<div class="searchResults">
					<?php 
					 if(isset($_SESSION['searchResult'])){;?>
					 <span class="sResults">Search Results</span></br>
						<table width="460">
							<tr bgcolor="gray">
								<th>Patient ID:</th> <th>Patient Name:</th> <th>Date Admitted</th>  <th>Illness Description</th>
							</tr>
							<tr bgcolor="lightgray" style="color:gray">
								<td width="15%" align="center"><?php echo $_SESSION['searchResult']->getID();?></td>
								<td width="35%" align="center"><?php echo $_SESSION['searchResult']->getName();?></td>
								<td width="20%" align="center"><?php echo $_SESSION['searchResult']->getDate();?></td>  
								<td width="30%" align="center"><?php echo $_SESSION['searchResult']->getIllnessDescription();?></td> 
							</tr>
						</table>
						</br>
						
					<?php
						unset($_SESSION['searchResult']);
					}
					?>
				</div>
				<div class="patients">
					<form method="post" action="patient_view.php">
					<?php
						require_once("Controller.php");
						$contr_obj=new Controller();
						$patients=$contr_obj->getPatient(0,"yes");
						$num=mysql_num_rows($patients);
						if($num>0){?>
							<input type="button" value=" Edit " class="command" name="edit" onClick="editPatient()" />
							<input type="submit" value="Delete" class="command" name="delete"/>
							<table width="600px">
							<tr bgcolor="gray">
							<th>?</th>
							<th>Patient ID</th>
							<th>Patient Name</th>
							<th>Date Admitted</th>
							<th>Residence</th>
							<th>Illness Summary</th>
							</tr>
							<?php
								for($i=0;$i<$num;$i++){
									$row=mysql_fetch_row($patients);?>
									<tr bgcolor="lightgray" style="color:gray">
										<td width= "3%" align="center"><input name="id" class="pat_ID"type="radio" value="<?php echo $row[0];?>"/></td>
										<td width= "12%" align="center"><?php echo $row[0];?></td>
										<td width="25%" align="center" class="pat_name" ><?php echo $row[1];?></td>
										<td width="15%" align="center" class="date_admitted"><?php echo $row[6];?></td>
										<td width="15%" align="center" class="residence"><?php echo $row[3];?></td>
										<td width="30%" align="center" class="illness"><?php echo $row[7];?></td>
									</tr>
								<?php ;}
							?>
							</table>
						<?php ;
						}
						else{
							echo "No Record of Patient Information";
						}
					?>
					</form>
				</div>
				<h5 style="color:orange"><?php echo $_SESSION['alert']; ?></h5>
			</div>
		</div>		
	</body>
</html>
<?php ;}?>