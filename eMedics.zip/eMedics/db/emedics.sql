-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2014 at 10:36 AM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `schoolms`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE IF NOT EXISTS `consultation` (
  `patient_ID` varchar(8) NOT NULL,
  `doctor_ID` varchar(8) NOT NULL,
  `date_attended` date NOT NULL,
  `nurse_ID` varchar(8) NOT NULL,
  `doctor_name` varchar(30) NOT NULL,
  `date_scheduled` date NOT NULL,
  `doctor_remark` text NOT NULL,
  `prescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consultation`
--

INSERT INTO `consultation` (`patient_ID`, `doctor_ID`, `date_attended`, `nurse_ID`, `doctor_name`, `date_scheduled`, `doctor_remark`, `prescription`) VALUES
('11239', '960', '1992-11-12', '66754', 'Dr. Danso', '1992-11-12', 'Health is improving', 'Continuation of usual medication');

-- --------------------------------------------------------

--
-- Table structure for table `opd_info`
--

CREATE TABLE IF NOT EXISTS `opd_info` (
  `height` decimal(11,0) NOT NULL,
  `temperature` decimal(11,0) NOT NULL,
  `blood_pressure` decimal(11,0) NOT NULL,
  `weight` decimal(11,0) NOT NULL,
  `nurse_ID` varchar(8) NOT NULL,
  `nurse_name` varchar(30) NOT NULL,
  `patient_ID` varchar(8) NOT NULL,
  `date_attended` date NOT NULL,
  PRIMARY KEY (`patient_ID`,`date_attended`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opd_info`
--

INSERT INTO `opd_info` (`height`, `temperature`, `blood_pressure`, `weight`, `nurse_ID`, `nurse_name`, `patient_ID`, `date_attended`) VALUES
(1, 33, 170, 59, '66754', 'Kesewaa', '11239', '1992-11-12');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `patient_ID` varchar(8) NOT NULL,
  `patient_name` varchar(30) NOT NULL,
  `patient_hometown` varchar(15) NOT NULL,
  `patient_residence` varchar(15) NOT NULL,
  `date_of_birth` date NOT NULL,
  `parent_name` varchar(30) NOT NULL,
  `date_admitted` date NOT NULL,
  `illness_description` text NOT NULL,
  PRIMARY KEY (`patient_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_ID`, `patient_name`, `patient_hometown`, `patient_residence`, `date_of_birth`, `parent_name`, `date_admitted`, `illness_description`) VALUES
('11239', 'Augustine Amoah', 'Kwaho Obo', 'Accra', '2012-11-15', 'Nat Asaam', '2014-06-11', ' Malaria symptoms and severe cholera'),
('54329', 'Patricia Davidson', 'Capecoast', 'Tema', '1987-02-23', 'Florence Davidson', '2014-03-12', ' Malaria Symptoms'),
('56780', 'Kwao Daniel', 'Somanya', 'Tema', '1987-02-20', 'Tetteh Jonas', '2014-03-17', ' Skin Infection that has endured for about a month'),
('67810', 'Joseph Dantey', 'Kumasi', 'Accra', '2001-09-12', 'Emmanuel Denteh', '2014-03-27', ' Cholera'),
('70223', 'Tetteh James', 'Somanya', 'Accra', '2002-03-04', 'Teye Matthew', '2014-03-15', 'Skin Rashes'),
('80919', 'Kwame Agyemang', 'Kumasi', 'Suhum', '1980-08-20', 'Seth Agyemang', '2014-11-15', 'Measle and syptoms and Rubella'),
('88813', 'Kweku Isaac', 'Somanya', 'Takoradi', '2014-03-04', 'Tetteh Ebenezer', '2014-03-11', 'Malaria fever'),
('90876', 'Kwabena Ampofo', 'Aburi', 'Kwabenya', '0000-00-00', 'Joseph Ampofo', '0000-00-00', ' Constipation and Mensural fever coupouled with catarh');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('kwasung', 'kwasung_chinchun');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
