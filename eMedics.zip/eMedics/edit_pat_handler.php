<?php
echo "here";

/*
	if(isset($_GET['old_ID'])){
		require_once("Controller.php");
		$obj=new Controller();
		$id=$_GET['old_id'];
		$newId=$_GET['newId'];
		$pat_name=$_GET['pat_name'];
		$pat_hometown=$_GET['pat_hometown'];
		$pat_residence=$_GET['pat_residence'];
		$dob=$_GET['dob'];
		$parent_name=$_GET['parent_name'];
		$date_admitted=$_GET['date_admitted'];
		$illness_description=$_GET['illness_description'];
		if($obj->editPatient($id,$newId,$pat_name,$pat_hometown,$pat_residence,$dob,$parent_name, $date_admitted,$illness_description)){
			echo 1;
		}
		else{
			echo 0;
		}
		
	}
	*/
?>