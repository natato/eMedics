<?php
	require_once("Opd_Info.php");
	require_once("Consultation.php");
	require_once("Patient.php");
	class Controller{
		var $host;
		var $link;
		var $str_error;
		var $dbname;
		var $username;
		var $password;
		var $results;
		function Controller(){
			$this->host="localhost";
			$this->link=false;
			$this->str_error="";
			$this->dbname="emedics";
			$this->username="root";
			$this->password="";
		}
		function newPatient($patient_ID, $patient_name,$patient_hometown,$patient_residence,$date_of_birth, $parent_name,$date_admitted,$illness_description){
			$sql_query="INSERT INTO patient VALUES('$patient_ID','$patient_name','$patient_hometown','$patient_residence','$date_of_birth','$parent_name','$date_admitted','$illness_description')";
			
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
				
			}
			return $this->results;
		}
		function newConsultation($patient_ID,$doctor_ID,$date_attended,$nurse_ID,$doctor_name,$date_scheduled,$doctor_remark,$prescription){
			$sql_query="INSERT INTO consultation VALUES('$patient_ID','$doctor_ID','$date_attended','$nurse_ID','$doctor_name','$date_scheduled','$doctor_remark','$prescription')";
			
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
			}
			return $this->results;
		}
		function newOpd_Info($height,$temperature,$blood_pressure,$weight,$nurse_ID,$nurse_name,$patient_ID,$date_attended){
			$sql_query="INSERT INTO opd_info VALUES('$height','$temperature','$blood_pressure','$weight','$nurse_ID','$nurse_name','$patient_ID','$date_attended')";
			
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
			}
			return $this->results;
		}
		
		function getPatient($patient_ID,$all="no"){
			$sql_query="SELECT * FROM patient WHERE patient_ID='$patient_ID'";
			$patient;
			if($all!="no"){
				$sql_query="SELECT * FROM patient";
			}
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
			}
			$patient="";
			if($all!="no"){
				return $this->results;
			}
			else{
				$num=mysql_num_rows($this->results);
				if($num>0){
					$row=mysql_fetch_row($this->results);
					$patient=new Patient($row[0],$row[1],$row[6]);
					$patient->setHometown($row[2]);
					$patient->setResidence($row[3]);
					$patient->setBirthDate($row[4]);
					$patient->setParentName($row[5]);
					$patient->setIllnessDescription($row[7]);
				}
			}
			return $patient;
		}
		function getConsultation($patient_ID, $date_attended){
			$sql_query="SELECT * FROM consultation WHERE patient_ID='$patient_ID' AND date_attended='$date_attended'";
			$consultation="";
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
				else{
					$num=mysql_num_rows($this->results);
					if($num>0){
						$row=mysql_fetch_row($this->results);
						$consultation= new Consultation($row[0],$row[1],$row[2]);
						$consultation->setDoctorName($row[4]);
						$consultation->setScheduledDate($row[5]);
						$consultation->setRemarks($row[6]);
						$consultation->setPrescription($row[7]);
						$opd_info=$this->getOpd_Info($patient_ID,$date_attended);
						$consultation->setOPDInfo($opd_info);
					}
				}
			}
			return $consultation;
		}
		function getOpd_Info($patient_ID,$date_attended){
			$sql_query="SELECT * FROM opd_info WHERE patient_ID='$patient_ID' AND date_attended='$date_attended'";
			$opd_info="";
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
				else{
					$num=mysql_num_rows($this->results);
					if($num>0){
						$row=mysql_fetch_row($this->results);
						$opd_info=new Opd_Info($row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7]);
					}
				}
			}
			return $opd_info;
		}
		function deletePatient($id){
			$sql_query="DELETE FROM patient WHERE patient_ID='$id'";
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
				else{
					return true;
				}
			}	
		}
		function editPatient($id,$newId,$pat_name,$pat_hometown,$pat_residence,$dob,$parent_name, $date_admitted,$illness_description){
			$sql_query="UPDATE patient SET patient_ID='$newId',patient_name='$pat_name',patient_hometown='$pat_hometown',patient_residence='$pat_residence',date_of_birth='dob',parent_name='$parent_name',date_admitted='$date_admitted',illness_description='$illness_description' WHERE patient_ID='$id'";
			$this->link=mysql_connect($this->host,$this->username,$this->password);
			if(!$this->link){
				$this->str_error="Connection failed. ";
				return false;
			}
			if(!mysql_select_db($this->dbname,$this->link)){
				$this->str_error="Could not select db due to ". mysql_error($this->link);
				return false;
			}
			else{
				$this->results=mysql_query($sql_query,$this->link);
				if(!$this->results){
					echo "error";
					$this->str_error="Query failed due to " . mysql_error($this->link);
					return false;
				}
				else{
					return true;
				}
			}
		}
	}
?>