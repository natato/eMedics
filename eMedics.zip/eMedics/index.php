<?php
	session_start();
	if(isset($_POST['loginButt'])){
		$uname=$_POST['uname'];
		$pass=$_POST['pass'];
		//$link=mysql_connect("localhost","school_ms","pass_school_ms");
		$link=mysql_connect("localhost","root","");
		$selected=mysql_select_db("emedics",$link);
		if($selected){
			$query="SELECT * FROM user WHERE username='$uname' AND password='$pass'";
			$result=mysql_query($query,$link);
			if($result){
				if(mysql_num_rows($result)==1){
					$row=mysql_fetch_row($result);
					$_SESSION['username']=$row[0];
					header("location:patient_view.php");
				}
			}
		}	
	}
	else{
		session_destroy();
	}
?>
<html>
	<head>
		<title>Medics Hospital Management System</title>
		<style>
			#login{
				margin:0 auto;
				width:350px;
				font-family:times,arial;
				font-size:11pt;
			}
			.loginButt{
				cursor:pointer;
				background-color:lightgray;
			}
		</style>
	</head>
	<body>
		</br></br></br></br>		
		<div id="login">
		<form method="post" action="index.php">
			Username: <input type="text" name="uname"/></br></br>
			Password: <input type="password" name="pass"/></br></br>
			<input type="submit" class="loginButt" name="loginButt" value="Login"/>
		</form>
		</div>
	</body>
</html>