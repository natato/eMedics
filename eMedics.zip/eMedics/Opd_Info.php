<?php
	class Opd_Info{
		var $height;
		var $temperature;
		var $blood_pressure;
		var $weight;
		var $nurse_ID;
		var $nurse_name;
		var $patient_ID;
		var $date_attended;
		function Opd_Info($height,$temperature,$blood_pressure,$weight,$nurse_ID,$nurse_name,$patient_ID,$date_attended){
			$this->height=$height;
			$this->temperature=$temperature;
			$this->blood_pressure=$blood_pressure;
			$this->weight=$weight;
			$this->nurse_ID=$nurse_ID;
			$this->nurse_name=$nurse_name;
			$this->patient_ID=$patient_ID;
			$this->date_attended=$date_attended;
		}
		function getNurseID(){
			return $this->nurse_ID;
		}
		function getNurseName(){
			return $this->nurse_name;
		}
		function getPatient_ID(){
			return $this->patient_ID;
		}
		function getTemperature(){
			return $this->temperature;
		}
		function getBloodPressure(){
			return $this->blood_pressure;
		}
		function getWeight(){
			return $this->weight;
		}
		function getHeight(){
			return $this->height;
		}
		function getDateAttended(){
			return $this->date_attended;
		}
	}
?>