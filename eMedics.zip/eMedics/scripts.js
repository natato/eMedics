var pat_ids_vals;
var xmlhttp;
var error_var;
var count;
function show(chBox_num){
	switch(chBox_num){
		case 1:
			var checked=document.getElementById("checkbox1").checked;
			var input=document.getElementById("search_pat_id");
			if(checked){
				input.style.visibility="visible";
			}
			else{
				input.style.visibility="hidden";
			}
		break;
		case 2:
			var checked=document.getElementById("checkbox2").checked;
			var input=document.getElementById("search_doc_id");
			if(checked){
				input.style.visibility="visible";
			}
			else{
				input.style.visibility="hidden";
			}
		break;
		case 3:
			var checked=document.getElementById("checkbox3").checked;
			var input=document.getElementById("search_nur_id");
			if(checked){
				input.style.visibility="visible";
			}
			else{
				input.style.visibility="hidden";
			}
		
		break;
		case 4:
			var checked=document.getElementById("checkbox4").checked;
			var input1=document.getElementById("search_day");
			var input2=document.getElementById("search_month");
			var input3=document.getElementById("search_year");
			if(checked){
				input1.style.visibility="visible";
				input2.style.visibility="visible";
				input3.style.visibility="visible";
			}
			else{
				input1.style.visibility="hidden";
				input2.style.visibility="hidden";
				input3.style.visibility="hidden";
			}
		
		break;
	}
}
function load(){
	if(window.XMLHttpRequest){
		xmlhttp=XMLHttpRequest();
	}
	else{
		xmlhttp=ActiveXObject();
	}
}
function showPatients(){
	
}

function showPatient(id){
	load();
	xmlhttp.onreadystatechange=handleShowPatient;
	var url="showPat.php?id="+id;
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
}
function handleShowPatient(){
	if (xmlhttp.readyState==4 && xmlhttp.status==200){
		// write code that shows details of a patient in the edit_patient.php page
	}
}

function editPatient(){
	var id=0;
	id=document.getElementsByName("id");
	var num=id.length;
	var val=-1;
	for(i=0;i<num;i++){
		if(id[i].checked==true){
			val=id[i].value;
			break;
		}
	}
	if(val==-1){
		alert("No Patient selected");
		return;
	}
	window.location="edit_patient.php?id="+val;
}
function editPatientDetail(){
	
	var id=document.getElementById("old_ID").value;
	var newId=document.getElementById("pat_ID").value;
	var pat_name=document.getElementById("pat_name").value;
	var pat_hometown=document.getElementById("hometown").value;
	var pat_residence=document.getElementById("residence").value;
	var dob=document.getElementById("year").value+"-"+document.getElementById("month").value+"-"+document.getElementById("day").value;
	var parent_name=document.getElementById("parent_name").value;
	var date_admitted=document.getElementById("year2").value+"-"+document.getElementById("month2").value+"-"+document.getElementById("day2").value;
	var illness_description=document.getElementById("illness").innerHTML;
	load();
	xmlhttp.onreadystatechange=handleEditPatient;
	var url="edit_handler.php?id="+id+"&newId="+newId+"&pat_name="+pat_name+"&pat_hometown="+pat_hometown+"&pat_residence="+pat_residence+"&dob="+dob+"&parent_name="+parent_name+"&date_admitted="+date_admitted+"&illness_description="+illness_description;
	
	xmlhttp.open("GET",url,true);
	xmlhttp.send();
	
}
function handleEditPatient(){
	if (xmlhttp.readyState==4 ){
		
		if(xmlhttp.responseText==1){
			alert("Patient Edited");
		}
		else{
			alert(xmlhttp.responseText);
			alert("Edit was not successful");
		}
	}
}
