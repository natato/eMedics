<?php
	class Patient{
		var $patient_ID;
		var $patient_name;
		var $patient_hometown;
		var $patient_residence;
		var $date_of_birth;
		var $parent_name;
		var $date_admitted;
		var $illness_description;
		function Patient($patient_ID,$patient_name,$date_admitted){
			$this->setID($patient_ID);
			$this->setName($patient_name);
			$this->setDate($date_admitted);
		}
		function setID($patient_ID){
			$this->patient_ID=$patient_ID;
		}
		function setName($patient_name){
			$this->patient_name=$patient_name;
		}
		function setDate($date_admitted){
			$this->date_admitted=$date_admitted;
		}
		function setHometown($patient_hometown){
			$this->patient_hometown=$patient_hometown;
		}
		function setResidence($patient_residence){
			$this->patient_residence=$patient_residence;
		}
		function setBirthDate($date_of_birth){
			$this->date_of_birth=$date_of_birth;
		}
		function setParentName($parent_name){
			$this->parent_name=$parent_name;
		}
		function setIllnessDescription($illness_description){
			$this->illness_description=$illness_description;
		}
		
		function getID(){
			return $this->patient_ID;
		}
		function getName(){
			return $this->patient_name;
		}
		function getDate(){
			return $this->date_admitted;
		}
		function getHometown(){
			return $this->patient_hometown;
		}
		function getResidence(){
			return $this->patient_residence;
		}
		function getBirthDate(){
			return $this->date_of_birth;
		}
		function getParentName(){
			return $this->parent_name;
		}
		function getIllnessDescription(){
			return $this->illness_description;
		}
	}

?>