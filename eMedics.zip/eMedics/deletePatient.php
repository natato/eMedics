<?php
	if(isset($_POST['edit'])){
		echo "edit";
		/*
		require_once("Controller.php");
		$contr_obj=new Controller();
		$id=$_GET['id'];
		if($contr_obj->deletePatient($id)){
			echo "success";
		}
		*/
		}
		else if (isset($_POST['delete'])){
			echo "delete";
		}
	
?>