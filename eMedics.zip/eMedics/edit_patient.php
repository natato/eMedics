<?php 
	session_start();
	$_SESSION['alert']="";
	if(isset($_GET['id'])){
		require_once("Controller.php");
		$obj=new Controller();
		$id=$_GET['id'];
		$patient=$obj->getPatient($id);
		$_SESSION['pat']=$patient;
		$dob=$_SESSION['pat']->getBirthDate();
		$date_admitted=$_SESSION['pat']->getDate();
		$_SESSION['dob']=explode("-",$dob);
		$_SESSION['date']=explode("-",$date_admitted);
	}
	
?>
<?php if(isset($_SESSION['username'])){?>
<html>
	<head> 
		<title>Edit Patient</title> 
		<link rel="stylesheet" href="patient_view.css" type="text/css"/>
		<script type="text/javascript" src="scripts.js"> </script>
		<style>
			#edit_pat{
				width:480px;
				height:500px;
				float:right;
				margin-right:10px;
			}
		</style>
	</head>
	<body>
		<div id="container">
			<div id="banner">
				<div class="logo">
					<i><h3>Medics Hospital Management System</h3></i>
				</div>
				<div class="menu">
					<div>
						Patient ID:</br>
						<form action="patient_view.php" method="post">
							<input type="text" name="pat_ID"/> <input name="search" type="submit" value="Search"/>
						</form>
					</div>
					<a href="patient_view.php">Patients</a>
					<a href="consultation_view.php">Consultation</a>
					<a href="index.php">Logout</a>
				</div>
			</div>
			</br>
			<div id="edit_pat">
			<form action="edit_patient.php" method="post">
				<u style="color:gray">Edit Patient Panel</u></br></br>
				<table>
				<tr>
					<td>
						Patient ID:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="pat_ID" value="<?php echo $_SESSION['pat']->getID(); ?>" class="big_input"/>
					</td>
					<td>
						Patient Name:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="pat_name" value="<?php echo $_SESSION['pat']->getName(); ?>" class="big_input"/>
					</td>
				</tr>
				<tr>
					<td>
						Hometown:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="hometown" value="<?php echo $_SESSION['pat']->getHometown(); ?>" class="big_input"/>
					</td>
					<td>
						Residence:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="residence" value="<?php echo $_SESSION['pat']->getResidence(); ?>" class="big_input"/>
					</td>
				</tr>
				<tr>
					<td>
						Date of Birth:(dd-mm-yyyy)</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="day" value="<?php echo $_SESSION['dob'][2]; ?>" class="small_input"/>
						<input type="text" id="month" value="<?php echo $_SESSION['dob'][1]; ?>" class="small_input"/>
						<input type="text" id="year" value="<?php echo $_SESSION['dob'][0]; ?>" class="small_input"/>
					</td>
					<td>
						Parent Name:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="parent_name" value="<?php echo $_SESSION['pat']->getParentName(); ?>" class="big_input"/>
					</td>
				</tr>
				<tr>
					<td>
						Date Admitted:(dd-mm-yyyy)</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="day2" value="<?php echo $_SESSION['date'][2]; ?>" class="small_input"/>
						<input type="text" id="month2" value="<?php echo $_SESSION['date'][1]; ?>" class="small_input"/>
						<input type="text" id="year2" value="<?php echo $_SESSION['date'][0]; ?>" class="small_input"/>
					</td>
					<td>
						Illness Description:</br>
						&nbsp;&nbsp;&nbsp;&nbsp;<textarea  id="illness" ><?php echo $_SESSION['pat']->getIllnessDescription(); ?></textarea>
					</td>
				</tr>
				</table>
				<input name="addPatient" type="button" value="Edit Patient" onClick="editPatientDetail()"> <input id="old_ID" type="hidden" value="<?php echo $_SESSION['pat']->getID(); ?>">
				</form>
			</div>
			
		</div>		
	</body>
</html>
<?php ;}?>