<?php
	class Consultation{
		var $patient_ID;
		var $doctor_ID;
		var $doctor_name;
		var $date_attended;
		var $date_scheduled;
		var $opd_info;
		var $doctor_remark;
		var $prescription;
		function Consultation($patient_ID,$doctor_ID,$date_attended){
			$this->patient_ID=$patient_ID;
			$this->doctor_ID=$doctor_ID;
			$this->date_attended=$date_attended;
		}
		function getPatientID(){
			return $this->patient_ID;
		}
		function getDoctorID(){
			return $this->doctor_ID;
		}
		function getAttendedDate(){
			return $this->date_attended;
		}
		function setDoctorName($doctor_name){
			$this->doctor_name=$doctor_name;
		}
		function setScheduledDate($date_scheduled){
			$this->date_scheduled=$date_scheduled;
		}
		function setOPDInfo($opd_info){
			$this->opd_info=$opd_info;
		}
		function setRemarks($doctor_remark){
			$this->doctor_remark=$doctor_remark;
		}
		function setPrescription($prescription){
			$this->prescription=$prescription;
		}
		
		function getDoctorName(){
			return $this->doctor_name;
		}
		function getScheduledDate(){
			return $this->date_scheduled;
		}
		function getOPDInfo(){
			return $this->opd_info;
		}
		function getRemarks(){
			return $this->doctor_remark;
		}
		function getPrescription(){
			return $this->prescription;
		}
	}

?>