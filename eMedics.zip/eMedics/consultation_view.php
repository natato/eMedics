<?php
	session_start();
	require_once("Controller.php");
	$contr_obj=new Controller();
	function isEmpty($variable,$error_msg){
		if(empty($variable)){
			$_SESSION['alert']=$error_msg;
			return true;
		}
		return false;
	}
	function addConsultation(){
		$contr_obj=new Controller();
		$pat_id=$_POST['pat_ID'];
		if(isEmpty($pat_id,"Patient ID field is empty")){
			return 0;
		}
		$doc_id=$_POST['doc_ID'];
		if(isEmpty($doc_id,"Doctor ID field is empty")){
			return 0;
		}
		$date_att=$_POST['date_att'];
		if(isEmpty($date_att,"Date Attended field is empty")){
			return 0;
		}
		$date_sch=$_POST['date_sch'];
		if(isEmpty($date_sch,"Date Scheduled field is empty")){
			return 0;
		}
		$height=$_POST['height'];
		if(isEmpty($height,"Height field is empty")){
			return 0;
		}
		$weight=$_POST['weight'];
		if(isEmpty($weight,"Weight field is empty")){
			return 0;
		}
		$temp=$_POST['temp'];
		if(isEmpty($temp,"Temperature field is empty")){
			return 0;
		}
		$BP=$_POST['BP'];
		if(isEmpty($BP,"Blood Pressure field is empty")){
			return 0;
		}
		$nurse_ID=$_POST['nurse_ID'];
		if(isEmpty($nurse_ID,"Nurse ID field is empty")){
			return 0;
		}
		$nurse_name=$_POST['nurse_name'];
		if(isEmpty($nurse_name,"Nurse name field is empty")){
			return 0;
		}
		$prescription=$_POST['prescription'];
		if(isEmpty($prescription,"Prescription field is empty")){
			return 0;
		}
		$remarks=$_POST['remarks'];
		if(isEmpty($remarks,"Remarks field is empty")){
			return 0;
		}
		$doc_name=$_POST['doc_name'];
		if(isEmpty($doc_name,"Doctor Name field is empty")){
			return 0;
		}
		$contr_obj-> newOpd_Info($height,$temp,$BP,$weight,$nurse_ID,$nurse_name,$pat_id,$date_att);
		$contr_obj->newConsultation($pat_id,$doc_id,$date_att,$nurse_ID,$doc_name,$date_sch,$remarks,$prescription);
		return 1;
	}
	if(isset($_POST['addConsultation'])){
		$result=addConsultation();
		if($result==1){
			$_SESSION['alert']="Consulatation added successfully";
		}
	}
	else if(isset($_POST['search'])){
		header("location:patient_view.php");
	}
	
?>
<?php if(isset($_SESSION['username'])){?>
<html>
	<head> 
		<title>Consultation View</title> 
		<link rel="stylesheet" href="consultation_view.css" type="text/css"/>
		<script type="text/javascript" src="scripts.js"> </script>
	</head>
	<body>
		<div id="container">
		
			<div id="banner">
				<div class="logo">
					<i><h3>Medics Hospital Management System</h3></i>
				</div>
				<div class="menu">
					<div class="search">
						Patient ID:</br>
						<form action="patient_view.php" method="post">
							<input type="text" name="pat_ID"/> <input name="search" type="submit" value="Search"/>
						</form>
					</div>
					<a href="patient_view.php">Patients</a>
					<a href="consultation_view.php">Consultation</a>
					<a href="index.php">Logout</a>
				</div>
			</div>
			</br>
			
			<div id="newConsultation">
				<u style="color:gray">New Consultation Panel</u></br></br>
				<form action="consultation_view.php" method="post">
				<table width="390px">
					<tr><td>Patient ID:<input type="text" name="pat_ID"/></td> <td>Doctor ID:<input type="text" name="doc_ID"/></td></tr>
					<tr><td>Date Scheduled:<input type="text" name="date_sch"/></td> <td>Date Attended:<input type="text" name="date_att"/></td></tr>
					<tr><td>Height:&nbsp;&nbsp;&nbsp;<input type="text" name="height"/></td> <td>Weight:<input type="text" name="weight"/></td></tr>
					<tr><td>Temperature:<input type="text" name="temp"/></td> <td>Blood Pressure:<input type="text" name="BP"/></td></tr>
					<tr><td>Nurse ID:<input type="text" name="nurse_ID"/></td> <td>Nurse Name:<input type="text" name="nurse_name"/></td></tr>
					<tr><td>Doctor's Remarks:<textarea name="remarks"></textarea></td> <td>Prescription:<textarea name="prescription"></textarea></td></tr>
					<tr><td>Doctor's Name:<input type="text" name="doc_name"/></td> <td></br><input name="addConsultation"type="submit" value="Save"/></td></tr>
				</table>
				</form>
			</div>
			</div id="findConsultation">
				<u style="color:gray">Search Consultation Panel</u></br></br>
				<div class="params">
					<form action="consultation_search.php" method="post">
					<i class="searchParams">Seach Parameters:</i>
					<table>
						<tr>
							<td><input type="checkbox" id="checkbox1" onClick="show(1)" /><i class="searchParams">Patient ID:</i></td>
							<td><input type="text"  name="search_pat_id" id="search_pat_id"  class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox2" onClick="show(2)"/><i class="searchParams">Doctor ID:</i></td>
							<td><input type="text" name="search_doc_id" id="search_doc_id" class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox3" onClick="show(3)"/><i class="searchParams">Nurse ID:</i></td>
							<td><input type="text" name="search_nur_id" id="search_nur_id" class="hid_text"/></td>
						</tr>
						<tr>
							<td><input type="checkbox" id="checkbox4" onClick="show(4)"/><i class="searchParams">Date(dd-mm-yyy):</i></td>
							<td>
								<input type="text" name="search_day" id="search_day" class="hid_text"/>
								<input type="text" name="search_month" id="search_month" class="hid_text"/>
								<input type="text" name="search_year" id="search_year" class="hid_text"/>
							</td>
						</tr>
					</table>
					<input type="submit" name="con_search" value="Search"/>
					</form>
				</div>
				<div id="results">
					<?php 
						if(isset($_SESSION['alert'])){
							echo "</br>"."<h5 style='color:orange'>".$_SESSION['alert']."</h5>";
						}
					?>
				</div>
			</div>
		</div>		
	</body>
</html>
<?php ;}?>